﻿
Public Class Sheet1

    Private Sub Sheet1_Startup() Handles Me.Startup
        MessageBox.Show("Customization has successfully loaded")
    End Sub

    Private Sub Sheet1_Shutdown() Handles Me.Shutdown

    End Sub

End Class
